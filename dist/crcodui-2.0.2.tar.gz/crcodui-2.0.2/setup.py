from setuptools import setup, find_packages

setup(
    name="CRCODUI",
    version="2.0.2",
    packages=find_packages(),
    author="crdex",
    author_email="crdexaymanambaby@gmail.com",
    description="manager your decorations + inputs, outputs, version code and extra arg",
    long_description="design all strings and your libraries and manage input , output, version, variable name mode",
    include_package_data=True,
    zip_safe=False,
    install_requires=[
        "python-cfonts", "colorama", 'rich', "pystyle", "autopep8", "termcolor"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
    ],
    python_requires=">=3.7",
)
