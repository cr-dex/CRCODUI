IMPORT           =          __import__ ((lambda ÆÞÞßŒµæÆÞÞÞŒæßæÞæ ,ŒÆÆøæÆµæÆÞœÞæµøŒÞßßøÆŒæß ,ŒœœµµææøßæÆŒµÆÆµŒßÆµµ           =          chr :''.join ([ŒœœµµææøßæÆŒµÆÆµŒßÆµµ (œÞœœøœŒÆøŒµææøÆœµŒµµ ^ŒÆÆøæÆµæÆÞœÞæµøŒÞßßøÆŒæß )for œÞœœøœŒÆøŒµææøÆœµŒµµ in ÆÞÞßŒµæÆÞÞÞŒæßæÞæ ]))([139 ,143 ,146 ,141 ,144 ,150 ],194 ),globals (),locals (),[(lambda ÆÞÞßŒµæÆÞÞÞŒæßæÞæ ,ŒÆÆøæÆµæÆÞœÞæµøŒÞßßøÆŒæß ,ŒœœµµææøßæÆŒµÆÆµŒßÆµµ           =          chr :''.join ([ŒœœµµææøßæÆŒµÆÆµŒßÆµµ (œÞœœøœŒÆøŒµææøÆœµŒµµ ^ŒÆÆøæÆµæÆÞœÞæµøŒÞßßøÆŒæß )for œÞœœøœŒÆøŒµææøÆœµŒµµ in ÆÞÞßŒµæÆÞÞÞŒæßæÞæ ]))([214 ,210 ,207 ,208 ,205 ,203 ],159 )],1 ).IMPORT 
IMPORT ()

def COLOR (*args ):
    ßœÆÞøßæµßÆæÞŒµœÞÞ           =          [Colors .red_to_green ,Colors .green_to_red ,Colors .yellow_to_red ,Colors .red_to_yellow ,Colors .purple_to_red ,Colors .red_to_purple ,Colors .yellow_to_green ,Colors .green_to_yellow ,Colors .green_to_cyan ,Colors .cyan_to_green ]
    ÆµœœŒÞµŒµÆµµµæÞ           =          ''.join (map (str ,args ))
    return Colorate .Horizontal (random .choice (ßœÆÞøßæµßÆæÞŒµœÞÞ ),ÆµœœŒÞµŒµÆµµµæÞ )