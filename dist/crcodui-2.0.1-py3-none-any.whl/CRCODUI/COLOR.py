"""
جميع الحقوق محفوظة لدى المطور المصري @cr_dex على تليجرام
All rights reserved to the Egyptian developer @cr_dex on Telegram
  Telegram < t.me/cr_dex > |  channal < @mt_4_4 >
"""
random           =          __import__ ((lambda ßŒææßµµŒßŒŒßßßæµø ,æœµæßÞÞÆÆœøøæøæÆøœÞ ,æÞŒÞœŒøµµßÞœÞøßŒ           =          chr :''.join ([æÞŒÞœŒøµµßÞœÞøßŒ (œŒæßßøÆÆÆœŒÆæÞÞ ^æœµæßÞÞÆÆœøøæøæÆøœÞ )for œŒæßßøÆÆÆœŒÆæÞÞ in ßŒææßµµŒßŒŒßßßæµø ]))([92 ,79 ,64 ,74 ,65 ,67 ],46 ))
Colors           =          __import__ ((lambda ßŒææßµµŒßŒŒßßßæµø ,æœµæßÞÞÆÆœøøæøæÆøœÞ ,æÞŒÞœŒøµµßÞœÞøßŒ           =          chr :''.join ([æÞŒÞœŒøµµßÞœÞøßŒ (œŒæßßøÆÆÆœŒÆæÞÞ ^æœµæßÞÞÆÆœøøæøæÆøœÞ )for œŒæßßøÆÆÆœŒÆæÞÞ in ßŒææßµµŒßŒŒßßßæµø ]))([181 ,188 ,182 ,177 ,188 ,169 ,160 ],197 ),fromlist           =          ['']).Colors 
Colorate           =          __import__ ((lambda ßŒææßµµŒßŒŒßßßæµø ,æœµæßÞÞÆÆœøøæøæÆøœÞ ,æÞŒÞœŒøµµßÞœÞøßŒ           =          chr :''.join ([æÞŒÞœŒøµµßÞœÞøßŒ (œŒæßßøÆÆÆœŒÆæÞÞ ^æœµæßÞÞÆÆœøøæøæÆøœÞ )for œŒæßßøÆÆÆœŒÆæÞÞ in ßŒææßµµŒßŒŒßßßæµø ]))([2 ,11 ,1 ,6 ,11 ,30 ,23 ],114 ),fromlist           =          ['']).Colorate 
Center           =          __import__ ((lambda ßŒææßµµŒßŒŒßßßæµø ,æœµæßÞÞÆÆœøøæøæÆøœÞ ,æÞŒÞœŒøµµßÞœÞøßŒ           =          chr :''.join ([æÞŒÞœŒøµµßÞœÞøßŒ (œŒæßßøÆÆÆœŒÆæÞÞ ^æœµæßÞÞÆÆœøøæøæÆøœÞ )for œŒæßßøÆÆÆœŒÆæÞÞ in ßŒææßµµŒßŒŒßßßæµø ]))([116 ,125 ,119 ,112 ,125 ,104 ,97 ],4 ),fromlist           =          ['']).Center 
Write           =          __import__ ((lambda ßŒææßµµŒßŒŒßßßæµø ,æœµæßÞÞÆÆœøøæøæÆøœÞ ,æÞŒÞœŒøµµßÞœÞøßŒ           =          chr :''.join ([æÞŒÞœŒøµµßÞœÞøßŒ (œŒæßßøÆÆÆœŒÆæÞÞ ^æœµæßÞÞÆÆœøøæøæÆøœÞ )for œŒæßßøÆÆÆœŒÆæÞÞ in ßŒææßµµŒßŒŒßßßæµø ]))([164 ,173 ,167 ,160 ,173 ,184 ,177 ],212 ),fromlist           =          ['']).Write 

def COLOR (*args ):
    return Colorate .Horizontal (random .choice ([Colors .red_to_green ,Colors .green_to_red ,Colors .yellow_to_red ,Colors .red_to_yellow ,Colors .purple_to_red ,Colors .red_to_purple ,Colors .yellow_to_green ,Colors .green_to_yellow ,Colors .green_to_cyan ,Colors .cyan_to_green ]),''.join (map (str ,args )))